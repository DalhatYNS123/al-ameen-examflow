AL-AMEEN EXAMFLOW v3.5.6 — INSTALLABLE HYBRID WEB APP (PWA)

WHAT THIS IS
This is the recommended mobile-installable version. It installs from the HTTPS
website with the official AL-AMEEN school emblem as its home-screen icon. It opens
in an app-style standalone window but runs the same web application using the
phone's browser engine. It is not a native APK.

DEPLOYMENT
1. Upload the complete project ZIP contents to your GitHub repository, preserving
   the pwa/ and .github/workflows/ folders.
2. In GitHub, open Settings > Pages and select "GitHub Actions" as the build/deploy
   source. In Settings > Actions > General, allow the workflow to run.
3. Open Actions > "Deploy EXAMFLOW PWA to GitHub Pages" > Run workflow.
4. Wait until the workflow has a green Success status.
5. Open the published Pages URL shown by the deployment. The URL normally ends
   with /<repository-name>/ because this is a project site.
6. On Android, open that URL in Google Chrome while online. Wait for the page to
   finish loading, then tap "Install EXAMFLOW" on the page or Chrome menu >
   Install app / Add to Home screen.
7. Confirm installation. The school emblem should appear as the app icon.
8. Open EXAMFLOW from the new home-screen icon. Load it once while online before
   testing offline operation.

MOBILE PRINTING / PDF
Use the installed EXAMFLOW app or open its HTTPS address in current Chrome.
Choose the app's PDF/Print action. Android should show the system print preview
when the browser and Android Print Service support it. Choose "Save as PDF",
select the destination and save. For physical printing, select the printer and
its supported paper/duplex settings. If no print preview appears, open the same
Pages URL directly in Chrome (not an embedded in-app browser), update Chrome,
and ensure Android's system Print Service is enabled. The app cannot force a
printer dialog or save to an arbitrary folder without the operating system's
permission.

OFFLINE AND ONLINE
- Paper creation, editing and local saved records are designed to work offline
  after the first successful online load and service-worker cache installation.
- WhatsApp, email, external links and online AI services require internet.
- First installation and first cache population require internet.
- Browser/site storage is local to this installed PWA on this device.

IMPORTANT DATA MIGRATION
The PWA has a separate browser storage origin from a file:// HTML copy or native
Android wrapper. Before switching, export a JSON backup from the old app. Install
and open this PWA, import the backup, and verify papers/drafts before deleting or
retiring the old copy. Keep the backup safely.

ICON
The manifest uses the supplied school-emblem icon in standard 192px/512px sizes and
safe-zone padded maskable 192px/512px variants for Android launcher masking.

LIMITS
This package does not include a precompiled APK. It provides the installable PWA
route requested: an app-style home-screen icon and a web-powered application.
Printing depends on the phone/browser print service. Test actual printing on the
target device before examination use.
