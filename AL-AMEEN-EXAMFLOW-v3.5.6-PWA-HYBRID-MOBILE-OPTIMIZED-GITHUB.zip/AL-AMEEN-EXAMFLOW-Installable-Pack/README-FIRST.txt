AL-AMEEN EXAMFLOW v3.5.6 — UPDATED INSTALLABLE WEB APP PACKAGE

RECOMMENDED ROUTE: INSTALLABLE PWA (HYBRID WEB APP)
For the requested mobile experience, use the pwa/ folder and the GitHub Pages
workflow. This installs on Android with the official school emblem as a home-screen
app icon and opens in an app-style window using the browser engine. It is a web
app, not a native APK.

FAST GITHUB STEPS
1. Extract this ZIP.
2. Upload the CONTENTS of the extracted folder (not the outer folder itself) to
   the root of your existing GitHub repository, preserving .github/ and pwa/.
3. Commit to the main branch.
4. GitHub repository > Settings > Pages > Build and deployment > Source:
   select GitHub Actions.
5. Actions > Deploy EXAMFLOW PWA to GitHub Pages > Run workflow.
6. Wait for green Success. Open the Pages URL from the deployment.
7. On Android Chrome, tap Install EXAMFLOW or use Chrome menu > Install app.
8. Launch from the school-logo icon.

DO NOT RUN THE ANDROID APK WORKFLOW FOR THIS PWA INSTALLATION ROUTE.
The Android Capacitor scaffold and Windows Electron scaffold are retained as
optional source packages from the supplied archive. They are not needed for the
home-screen hybrid web app.

PRESERVED SOURCE
- APPROVED-ORIGINAL-v3.5.6.html is retained unchanged.
- PWA index remains based on the supplied application, with PWA/install and
  online-contact clarity improvements.
- Original shared logo and Android/Windows scaffolds are retained.
- The PWA uses standard and Android-maskable 192px/512px icons derived from the
  official school emblem.

DATA SAFETY
Before changing from an older file/app, export a JSON backup. Import it into the
new PWA and verify papers and drafts. Different app/browser origins have separate
local storage; no automatic sync occurs.

PRINTING
The PDF action uses the browser/Android print preview. Choose Save as PDF there.
Printing is not a direct silent file write. If Android does not show print preview,
open the deployed URL in Chrome and check that Android Print Service is enabled.

INTERNET
First deployment/install/cache load requires internet. Core paper work is intended
to run offline after that. WhatsApp, email and online services require internet.
See pwa/README-PWA.txt for full steps and limitations.

This ZIP is installation source, not a compiled APK.
