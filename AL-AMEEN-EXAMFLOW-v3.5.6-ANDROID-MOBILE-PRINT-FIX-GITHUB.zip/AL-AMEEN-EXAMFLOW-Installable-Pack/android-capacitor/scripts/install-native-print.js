#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const androidRoot = path.resolve(__dirname, '..', 'android');
const appId = 'org.dynscore.alameenexamflow';
const packagePath = appId.split('.').join(path.sep);
const javaDir = path.join(androidRoot, 'app', 'src', 'main', 'java', packagePath);
const mainActivity = path.join(javaDir, 'MainActivity.java');
const pluginSource = path.resolve(__dirname, '..', 'native', 'NativePrintPlugin.java');
const pluginTarget = path.join(javaDir, 'NativePrintPlugin.java');

if (!fs.existsSync(mainActivity)) {
  throw new Error(`Capacitor MainActivity not found: ${mainActivity}`);
}
if (!fs.existsSync(pluginSource)) {
  throw new Error(`Native print plugin source not found: ${pluginSource}`);
}

let source = fs.readFileSync(mainActivity, 'utf8');
if (!source.includes('registerPlugin(NativePrintPlugin.class)')) {
  source = source.replace(
    /public void onCreate\(Bundle savedInstanceState\)\s*\{/,
    match => `${match}\n        registerPlugin(NativePrintPlugin.class);`
  );
  if (!source.includes('registerPlugin(NativePrintPlugin.class)')) {
    throw new Error('Could not safely register NativePrintPlugin in MainActivity.java');
  }
  fs.writeFileSync(mainActivity, source);
}
fs.copyFileSync(pluginSource, pluginTarget);
console.log('Installed and registered EXAMFLOW NativePrint Capacitor plugin.');
