package org.dynscore.alameenexamflow;

import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Opens Android's native print sheet for the HTML paper currently prepared
 * by EXAMFLOW. Android's WebView does not reliably implement window.print()
 * without a native PrintManager bridge.
 */
@CapacitorPlugin(name = "NativePrint")
public class NativePrintPlugin extends Plugin {

    @PluginMethod
    public void printHtml(PluginCall call) {
        final String html = call.getString("html");
        final String jobName = call.getString("jobName", "AL-AMEEN EXAMFLOW");

        if (html == null || html.trim().isEmpty()) {
            call.reject("No printable HTML was supplied.");
            return;
        }

        getActivity().runOnUiThread(() -> {
            try {
                Context context = getContext();
                PrintManager printManager =
                    (PrintManager) context.getSystemService(Context.PRINT_SERVICE);

                if (printManager == null) {
                    call.reject("Android print service is not available on this device.");
                    return;
                }

                final WebView printWebView = new WebView(context);
                printWebView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                printWebView.getSettings().setJavaScriptEnabled(false);
                printWebView.setWebViewClient(new WebViewClient() {
                    private boolean submitted = false;

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        super.onPageFinished(view, url);
                        if (submitted) return;
                        submitted = true;

                        try {
                            PrintDocumentAdapter adapter =
                                printWebView.createPrintDocumentAdapter(jobName);
                            PrintAttributes attributes = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                .build();

                            printManager.print(jobName, adapter, attributes);
                            JSObject result = new JSObject();
                            result.put("opened", true);
                            call.resolve(result);
                        } catch (Exception e) {
                            call.reject("Could not start Android printing: " + e.getMessage(), e);
                            printWebView.destroy();
                        }
                    }
                });

                // The app's HTML and styles are bundled locally. The base URL
                // preserves relative local asset resolution inside the print WebView.
                printWebView.loadDataWithBaseURL(
                    "https://localhost/",
                    html,
                    "text/html",
                    "UTF-8",
                    null
                );
            } catch (Exception e) {
                call.reject("Could not prepare the Android print document: " + e.getMessage(), e);
            }
        });
    }
}
